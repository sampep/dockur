#!/bin/bash

while true; do
    echo "$(date '+%Y-%m-%d %H:%M:%S')"
    sleep 600  # Wait for 600 seconds (10 minutes) before printing again
done